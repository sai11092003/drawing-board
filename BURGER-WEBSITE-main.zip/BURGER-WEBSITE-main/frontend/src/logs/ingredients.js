const initialIngredient = [
    { 
       name:"whole-wheat-bun",price: 20,count:0 },
    {name:"cheese-slice", price: 10,count:0 },
    {name:"lettuce", price: 20,count:0 },
   { name:"tomato",price: 20,count:0 },
    {name:"onion", price: 20,count:0 },
    {name:"pepper", price: 5,count:0 },
    { name:"olive-oil",price: 20,count:0 },
    {name:"garlic", price: 20,count:0 },
   { name:"patty",price: 30,count:0 }
   ];
 module.exports= initialIngredient;